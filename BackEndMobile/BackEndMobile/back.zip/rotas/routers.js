const express = require('express');
const router = express.Router();
const controllerSenai = require('../controllers/controllerSenai');

// cadastrar 
router.post('/cadastrar', controllerSenai.registrarColaborador);

// listar colaboradores
router.get('/listar', controllerSenai.listarSenai);

// atualizar colaborador
router.put('/atualizar/:id', controllerSenai.atualizar);

//  deletar colaborador
router.delete('/deletar/:id', controllerSenai.deletar);

module.exports = router;
